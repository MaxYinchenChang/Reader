import tkinter
import tkinter.ttk as ttk
import os
from tkinter import scrolledtext, messagebox
from note import notepad


def list():
    note_list = tkinter.Tk()
    note_list.title('笔记列表')
    note_list.geometry('400x600')
    note_list.resizable(False, False)

    tree = ttk.Treeview(note_list)
    tree.place(x=0, y=0, width=400, height=500)

    tree.heading('#0', text='名称')

    if os.path.isdir('note'):
        path = 'note'
        for file in os.listdir(path):
            file_path = os.path.join(path, file)

            tree.insert('', tkinter.END, text=file, values='')
    else:
        os.makedirs('note')

    def open_file():

        try:
            id = tree.selection()  # 使用selection()获得用户所选项id
            path = 'note/' + tree.item(id)['text']  # 根据获得的id查询内容，‘text’指定获取的项。
            print(path)
            file = open(path, 'r', encoding='utf-8')
            txt = file.read()
            # print(txt)
            note = tkinter.Tk()
            note.title('笔记本')
            note['width'] = 800
            note['height'] = 600
            note.resizable(False, False)

            ttk.Label(note, text='修改笔记', justify=tkinter.CENTER).place(x=350, y=30, width=100, height=25)
            note_info = tkinter.scrolledtext.ScrolledText(note, bd=3)
            note_info.place(x=0, y=50, width=800, height=550)
            note_info.insert(tkinter.INSERT, ''.join(txt))

            def save():
                file = open(path, 'w', encoding='utf-8', errors='UnicodeDecodeError')
                txt = note_info.get('1.0', tkinter.END)
                file.write(txt)
                note.destroy()

            ttk.Button(note, text='保存', command=save).place(x=0, y=0, width=75, height=25)

            note.mainloop()

        except UnicodeDecodeError or IsADirectoryError:
            tkinter.messagebox.showerror(title='错误', message='请确认文件格式是否为.txt格式,或是否已经选择文件。')

    def show_bookcase():
        note_list.destroy()
        notepad.note()

    ttk.Button(note_list, text='返回', command=note_list.destroy).place(x=175, y=575, width=75, height=25)

    ttk.Button(note_list, text='新建', command=show_bookcase).place(x=250, y=575, width=75, height=25)
    ttk.Button(note_list, text='打开', command=open_file).place(x=325, y=575, width=75, height=25)

    def treeviewClick(event):
        pass

    tree.bind('<Button-1>', treeviewClick)

    note_list.mainloop()
