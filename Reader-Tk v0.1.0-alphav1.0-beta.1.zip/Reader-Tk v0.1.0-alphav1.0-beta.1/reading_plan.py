import tkinter as tk
import tkinter.ttk as ttk
import csv
import InfoWindow

def plan():
    plan_win = tk.Tk()
    plan_win.title('阅读计划')
    plan_win.geometry('1000x690+0+0')
    plan_win.resizable(False, True)

    ttk.Label(plan_win, text='阅读计划', font=('黑体', 35)).place(x=0, y=0, width=300, height=50)
    tree_frame = ttk.Frame(plan_win)
    tree_frame.place(x=0, y=60, width=1000, height=575)
    scrollBar = ttk.Scrollbar(tree_frame)
    scrollBar.pack(side=tk.RIGHT, fill=tk.Y)
    columns = ['日期', '章节', '计划状态']
    plan_tree = ttk.Treeview(tree_frame, columns=columns, show='headings', yscrollcommand=scrollBar.set)
    plan_tree.place(x=0, y=0, width=100, height=575)

    plan_tree.column('日期', width=600, anchor='center')
    plan_tree.column('章节', width=200, anchor='center')
    plan_tree.column('计划状态', width=200, anchor='center')

    plan_tree.heading('日期', text='日期')
    plan_tree.heading('章节', text='章节')
    plan_tree.heading('计划状态', text='计划状态')

    ttk.Label(plan_win, text='阅读时间:').place(x=0, y=635, width=100, height=20)
    ttk.Label(plan_win, text='-').place(x=200, y=635, width=15, height=20)
    ttk.Label(plan_win, text='-').place(x=265, y=635, width=15, height=20)

    plan_time_year = tk.StringVar(plan_win, value='')
    plan_time_month = tk.StringVar(plan_win, value='')
    plan_time_day = tk.StringVar(plan_win, value='')
    plan_reading_passage = tk.StringVar(plan_win, value='')
    ttk.Entry(plan_win, textvariable=plan_time_year).place(x=100, y=635, width=100, height=20)
    ttk.Entry(plan_win, textvariable=plan_time_month).place(x=215, y=635, width=50, height=20)
    ttk.Entry(plan_win, textvariable=plan_time_day).place(x=280, y=635, width=50, height=20)

    ttk.Label(plan_win, text='书籍/章节：').place(x=25, y=655, width=75, height=20)
    ttk.Entry(plan_win, textvariable=plan_reading_passage).place(x=100, y=655, width=100, height=20)

    def finish_plan():
        iid = plan_tree.selection()
        text = plan_tree.item(iid)['values']
        date = text[0]
        passage = text[1]
        new_plan_info = [[date, passage, '已完成']]
        for index, data in enumerate(new_plan_info):
            plan_tree.insert('', tk.END, values=data)
        plan_tree.delete(iid)

    ttk.Button(plan_win, text='已完成', command=finish_plan).place(x=850, y=635, width=75, height=25)
    def insert():
        # 添加数据
        time = plan_time_year.get() + '-' + plan_time_month.get() + '-' + plan_time_day.get()
        passage = plan_reading_passage.get()
        state = '未完成'
        plan_info = [[time, passage, state]]
        for index, data in enumerate(plan_info):
            plan_tree.insert('', tk.END, values=data)
        plan_time_year.set(value='')  # 添加后清空内容。
        plan_time_month.set(value='')
        plan_time_day.set(value='')
        plan_reading_passage.set(value='')

    ttk.Button(plan_win, text='添加', command=insert).place(x=250, y=655, width=75, height=25)

    def delete():
        selected_item = plan_tree.selection()
        plan_tree.delete(selected_item)

    ttk.Button(plan_win, text='删除', command=delete).place(x=525, y=635, width=75, height=25)


    def load_file():
        with open('plan_file.csv') as plan_file:
            csvread = csv.reader(plan_file, delimiter=',')

            for row in csvread:
                plan_tree.insert('', tk.END, values=row)

        load_button = ttk.Button(plan_win, text='加载', command=load_file, state=tk.DISABLED).place(x=600, y=635, width=75,height=25)
        # state=tk.DISABLED 加载后立即替换可按按钮为禁用的不可按按钮，放置用户调皮重复加载。

    load_button = ttk.Button(plan_win, text='加载', command=load_file).place(x=600, y=635, width=75, height=25)

    def save_file():
        with open('plan_file.csv', 'w', newline='') as bookfile:
            csvsave = csv.writer(bookfile, delimiter=',')

            for row_id in plan_tree.get_children():
                row = plan_tree.item(row_id)['values']
                csvsave.writerow(row)

    ttk.Button(plan_win, text='保存', command=save_file).place(x=750, y=635, width=75, height=25)

    def reload():
        plan_tree.delete(*plan_tree.get_children())
        load_file()

    ttk.Button(plan_win, text='重载', command=reload).place(x=675, y=635, width=75, height=25)

    # 定义并绑定Treeview组件的鼠标单击事件

    def go_home():
        plan_win.destroy()

    ttk.Button(plan_win, text='返回', command=go_home).place(x=925, y=635, width=75, height=25)

    def treeviewClick(event):
        pass


    plan_tree.bind('<Button-1>', treeviewClick)

    plan_tree.pack(side=tk.LEFT, fill=tk.Y)
    scrollBar.config(command=plan_tree.yview)

    plan_win.mainloop()
