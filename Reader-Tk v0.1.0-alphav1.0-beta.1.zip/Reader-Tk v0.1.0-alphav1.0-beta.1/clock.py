import tkinter as tk
from tkinter import messagebox
import datetime


# 计时器计时状态
is_running = False
def clock():
    # 创建窗口
    window = tk.Tk()
    window.title("阅读计时器")
    window.geometry('300x350')

    # 添加标签用于显示倒计时时间
    time_label = tk.Label(window, text="00:00:00", font=('Arial', 30))
    time_label.pack(pady=20)

    # 添加文本框用于输入持续时间
    duration_entry = tk.Entry(window, font=('Arial', 16), width=10)
    duration_entry.pack(pady=10)
    duration_entry.insert(0, "3600")

    # 添加提示标签
    tip_label = tk.Label(window, text="请输入阅读时间（秒）并坚持到最后。", font=('Arial', 10))
    tip_label.pack(pady=2)

    # 添加开始/暂停计时按钮
    start_button = tk.Button(window, text="开始", font=('Arial', 18), width=10, height=1)
    start_button.pack(pady=10)

    # 添加停止计时按钮
    stop_button = tk.Button(window, text="停止", font=('Arial', 18), width=10, height=1)
    stop_button.pack(pady=10)



    # 计时器开始时间和持续时间（单位：秒）
    start_time = 0
    duration = 60

    # 时间转换函数
    def format_time(seconds):
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        seconds = seconds % 60
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"

    # 更新时间函数
    def update_time():
        global is_running, start_time, duration
        if is_running:
            remaining_time = duration - (datetime.datetime.now() - start_time).total_seconds()
            if remaining_time <= 0:
                # 计时结束，停止计时
                is_running = False
                start_button.config(text="开始")
                time_label.config(text=format_time(0))

            else:
                # 更新计时时间
                time_label.config(text=format_time(int(remaining_time)))
                # 每隔一秒钟更新一次
                window.after(1000, update_time)

    # 开始/暂停计时按钮的事件处理函数
    def start_button_click():
        global is_running, start_time, duration
        if is_running:
            # 停止计时
            is_running = False
            start_button.config(text="开始")
        else:
            # 开始计时
            duration = int(duration_entry.get())
            start_time = datetime.datetime.now()
            is_running = True
            start_button.config(text="暂停")
            update_time()

    # 停止计时按钮的事件处理函数
    def stop_button_click():
        global is_running
        is_running = False
        start_button.config(text="开始")
        time_label.config(text=format_time(0))

    # 绑定按钮单击事件
    start_button.config(command=start_button_click)
    stop_button.config(command=stop_button_click)


    def start_conversion():
        time_conversion = tk.Tk()
        time_conversion.title('时间换算')
        time_conversion.geometry('200x100')
        time_conversion.resizable(False, False)

        hour_con = tk.StringVar(time_conversion, value='')
        min_con = tk.StringVar(time_conversion, value='')
        sec_con = tk.StringVar(time_conversion, value='')

        tk.Label(time_conversion, text='请输入换算时间：').place(x=0, y=0, width=200, height=25)
        tk.Entry(time_conversion, textvariable=hour_con).place(x=0, y=25, width=40, height=25)
        tk.Label(time_conversion, text=':').place(x=40, y=25, width=10, height=25)
        tk.Entry(time_conversion, textvariable=min_con).place(x=50, y=25, width=40, height=25)
        tk.Label(time_conversion, text=':').place(x=90, y=25, width=10, height=25)
        tk.Entry(time_conversion, textvariable=sec_con).place(x=100, y=25, width=40, height=25)

        sec_conversion_label = tk.Label(time_conversion)
        sec_conversion_label.place(x=0, y=50, width=200, height=25)

        # 时间换算
        def conversion():
            if hour_con.get() and min_con.get() and sec_con.get() != '':
                sec_conversion = (int(hour_con.get()) * 3600) + (int(min_con.get()) * 60) + (int(sec_con.get()))
                sec_conversion = str(sec_conversion)
                sec_conversion_label.config(text=f'换算的时间为：{sec_conversion}秒')
            else:
                message = '''
                没有付出就没有回报，
                没有输入就没有输出。'''
                tk.messagebox.showerror(title='输入数据！', message=message)

        tk.Button(time_conversion, text='换算', command=conversion).place(x=50, y=75, width=75, height=25)
        tk.Button(time_conversion, text='返回', command=time_conversion.destroy).place(x=125, y=75, width=75, height=25)

        time_conversion.mainloop()

    tk.Button(window, text='换算', command=start_conversion, font=('Arial', 18), width=10, height=1).pack(pady=10)
    # 循环运行窗口程序
    window.mainloop()

