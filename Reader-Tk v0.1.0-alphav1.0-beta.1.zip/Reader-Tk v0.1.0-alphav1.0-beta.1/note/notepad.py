# 导入相关库
import tkinter
import tkinter.filedialog
import tkinter.colorchooser
import tkinter.messagebox
import tkinter.scrolledtext
import tkinter.simpledialog
import datetime
import random

# 直接打包功能为函数，在另外的程序中直接调用。
def note():
    app = tkinter.Tk()
    app.title('笔记本')
    app['width'] = 800
    app['height'] = 600

    textChanged = tkinter.IntVar(app, value=0)


    # 设置菜单
    menu = tkinter.Menu(app)

    submenu = tkinter.Menu(menu, tearoff=0)
    filename = str(datetime.datetime.now()) + '.txt' # 创建笔记，名为当日日期。
    def Save(new_filename=None):
        '''
        save功能可以保存文件。
        '''

        global filename
        if not filename:
            SaveAs()
        elif textChanged.get():
            with open(filename, 'w') as fp:
                fp.write(txtContent.get(0.0, tkinter.END))
            filename = new_filename
            textChanged.set(0)
    submenu.add_command(label='保存', command=Save)

    def Open():
        global filename
        if textChanged.get():
            yesno = tkinter.messagebox.askyesno(title='是否保存？',
                                                message='你想要保存吗？')
            if yesno == tkinter.YES:
                Save()

            filename = tkinter.filedialog.askopenfilename(title='打开文件',
                                                          filetypes=[('Text files', '*.txt')])
            if filename:
                txtContent.delete(0.0, tkinter.END)
                with open(filename, 'r') as fp:
                    txtContent.insert(tkinter.INSERT, ''.join(fp.readlines()))
                textChanged.set(0)
    submenu.add_command(label='打开', command=Open)

    def SaveAs():
        global filename
        file_name = str(datetime.date.today()) + str(random.randint(a=0, b=10001))
        newfilename = tkinter.filedialog.asksaveasfilename(title='另存为',
                                                           initialdir=r'c://',
                                                           initialfile=f'{file_name}.txt')
        if newfilename:
            with open(newfilename, 'w') as fp:
                fp.write(txtContent.get(0.0, tkinter.END))
            filename = newfilename
            textChanged.set(0)
    submenu.add_command(label='另存为', command=SaveAs)

    submenu.add_separator()


    def Close():
        global filename
        Save()
        txtContent.delete(0.0, tkinter.END)
        filename = ''
    submenu.add_command(label='关闭', command=Close)
    menu.add_cascade(label='文件', menu=submenu)

    submenu = tkinter.Menu(menu, tearoff=0)

    def Undo():
        txtContent['undo'] = True
        try:
            txtContent.edit_undo()
        except Exception as e:
            pass
    submenu.add_command(label='撤销', command=Undo)

    def Redo():
        txtContent['undo'] = True
        try:
            txtContent.edit_redo()
        except Exception as e:
            pass
    submenu.add_separator()

    def Copy():
        txtContent.clipboard_clear()
        txtContent.clipboard_append(txtContent.selection_get())
    submenu.add_command(label='复制', command=Copy)

    def Cut():
        Copy()
        txtContent.delete(tkinter.SEL_FIRST, tkinter.SEL_LAST)
    submenu.add_command(label='剪切', command=Cut)

    def Paste():
        try:
            txtContent.insert(tkinter.SEL_FIRST, txtContent.clipboard_get())
            txtContent.delete(tkinter.SEL_FIRST, tkinter.SEL_LAST)
            return
        except Exception as e:
            pass
        txtContent.insert(tkinter.INSERT, txtContent.clipboard_get())
    submenu.add_command(label='粘贴', command=Paste)

    submenu.add_separator()

    def Search():
        textToSearch = tkinter.simpledialog.askstring(title='搜索',
                                                     prompt='搜索对象')
        start = txtContent.search(textToSearch, 0.0, tkinter.END)

        if start:
            tkinter.messagebox.showinfo(title='Found', message='OK')
        else:
            tkinter.messagebox.showerror(title='Not Found', message='Fail')
    submenu.add_command(label='搜索', command=Search)
    menu.add_cascade(label='工具', menu=submenu)

    helpmenu = tkinter.Menu(menu, tearoff=0)
    def About():
        tkinter.messagebox.showinfo(title='关于',
                                    message='一个记事本')
    helpmenu.add_command(label='关于', command=About)
    menu.add_cascade(label='帮助', menu=helpmenu)

    app.config(menu=menu)

    txtContent = tkinter.scrolledtext.ScrolledText(app, wrap=tkinter.WORD)
    txtContent.pack(fill=tkinter.BOTH, expand=tkinter.YES)

    def KeyPress():
        textChanged.set(1)
    txtContent.bind('<KeyPress>', KeyPress)

    app.mainloop()

