import tkinter as tk
import tkinter.ttk as ttk
import bookcase, note_list, reading_plan, clock, ISBN_Checker

# 设置程序窗口。
home = tk.Tk()

window_width1 = 1200
window_height1 = 900
home.title('Reader')
home.resizable(False, False)

x_ = 65

# 使窗口位于屏幕中央。
width = int(round((home.winfo_screenwidth() - window_width1) / 2))
height = int(round((home.winfo_screenheight() - window_height1) / 2))
home.geometry(f'{window_width1}x{window_height1}+{width}+{height}')

# 初始化所有图片。
bookcase_pho = tk.PhotoImage(file='asset/bookcase.png')
bookcase_pho_ = bookcase_pho.subsample(x=20, y=20)
notebook_pho = tk.PhotoImage(file='asset/notebook.png')
notebook_pho_ = notebook_pho.subsample(x=20, y=20)
side_bar_pho = tk.PhotoImage(file='asset/side_bar.png')
side_bar_pho_ = side_bar_pho.subsample(x=20, y=20)
plan_pho = tk.PhotoImage(file='asset/plan.png')
plan_pho_ = plan_pho.subsample(x=20, y=20)
checker_pho = tk.PhotoImage(file='asset/SIBNChecker.png')
checker_pho_ = checker_pho.subsample(x=20, y=20)

# 构造一个公告框架。
notice_frame = ttk.Frame(home, width=1050, height=800)
notice_frame.place(x=100, y=0)

side_bar_label_frame = ttk.Frame(home, width=50, height=300)
side_bar_label_frame.place(x=50, y=0)

# 构建侧边栏函数
def close_side_bar():
    side_bar_label_frame.place_forget()
    side_bar_button.config(command=show_side_bar)
    notice_frame.place(x=50, y=0)

def show_side_bar():
    notice_frame.place_forget()
    side_bar_button.config(command=close_side_bar)
    side_bar_label_frame.place(x=50, y=0)
    notice_frame.place(x=100, y=0)

welcom_label = ttk.Label(notice_frame, text='欢迎👏使用Reader， 从这里开始你的阅读之旅。', font=('黑体', 30))
welcom_label.place(x=0, y=0, width=850, height=50)
welcome_en_label = ttk.Label(notice_frame, text='Welcome to use Reader,from here to start your reading journey.', font=('黑体', 15))
welcome_en_label.place(x=0, y=50, width=700, height=40)

ttk.Label(notice_frame, text='公告', font=('宋体', 25)).place(x=0, y=110, width=75, height=40)
text = '''
作者：常胤辰
内容介绍：通过书架，计划，笔记本来完成你的阅读，享受阅读带来的乐趣。
功能介绍：
- 书架：整理、保存你的书籍。
- 笔记本：阅读遇到了一些问题？有了一些收获？记录下它！在之后的复读中温习，看看有什么新的体味！
- 阅读计划：不能坚持读完书籍？通过建立计划来保证有序的阅读！
- ISBN检验：检验书籍ISBN的有效性。可能不是很有用，但是你不能确定用不上它！
- 更多功能：在修改完善中进步！ 
'''
ttk.Label(notice_frame, text=text, font=('仿宋')).place(x=0, y=150, width=1050, height=300)

side_bar_button = tk.Button(home, image=side_bar_pho_, command=close_side_bar, bd=0)
side_bar_button.place(x=0, y=15, width=50, height=50)
bookcase_button = tk.Button(home, image=bookcase_pho_, command=bookcase.bookcase_win, bd=0)
bookcase_button.place(x=0, y=75, width=50, height=50)
notebook_button = tk.Button(home, image=notebook_pho_, command=note_list.list, bd=0)
notebook_button.place(x=0, y=125, width=50, height=50)
plan_button = tk.Button(home, image=plan_pho_, command=reading_plan.plan, bd=0)
plan_button.place(x=0, y=175, width=50, height=50)
ckecker_button = tk.Button(home, image=checker_pho_, command=ISBN_Checker.ISBN_checker, bd=0)
ckecker_button.place(x=0, y=225, width=50, height=50)

bookcase_label = tk.Label(side_bar_label_frame, text='书架', font=(30))
bookcase_label.place(x=0, y=87, width=50, height=25)

notebook_label = tk.Label(side_bar_label_frame, text='笔记', font=(30))
notebook_label.place(x=0, y=137, width=50, height=25)

plan_label = tk.Label(side_bar_label_frame, text='计划', font=(30))
plan_label.place(x=0, y=187, width=50, height=25)

checker_label = tk.Label(side_bar_label_frame, text='检查', font=(30))
checker_label.place(x=0, y=237, width=50, height=25)

labelDateTime = tk.Label(home, width=130)
still = tk.IntVar(value=1)

def start_clock():
    clock.clock()

tk.Button(home, text='开始阅读计时', bd=0, background='white',bg='skyblue', font=('黑体', 35), command=start_clock).place(x=800, y=750, width=300, height=50)

home.mainloop()
