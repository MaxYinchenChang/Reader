import tkinter
from tkinter import messagebox

def ISBN_checker():
    # 设置窗口
    ISBN_Root = tkinter.Tk()
    ISBN_Root.title('ISBN 编码校验')

    ISBN_Root['height'] = 60
    ISBN_Root['width'] = 350

    labelName = tkinter.Label(ISBN_Root,
                              text='ISBN编码:',
                              justify=tkinter.RIGHT,
                              width=50)
    labelName.place(x=20, y=5, width=70, height=20)

    varName = tkinter.StringVar(ISBN_Root, value='')
    entryName = tkinter.Entry(ISBN_Root,
                              width=120,
                              textvariable=varName)
    entryName.place(x=90, y=5, width=225, height=20)


    class check():
        def validate_isbn13(isbn):
            # 移除可能包含的减号和空格
            isbn = isbn.replace("-", "").replace(" ", "")

            # ISBN必须是13位数字
            if len(isbn) != 13 or not isbn.isdigit():
                return False

            # 计算校验和
            sum_ = 0
            for i in range(0, 12, 2):
                sum_ += int(isbn[i])
            for i in range(1, 12, 2):
                sum_ += int(isbn[i]) * 3

            # 检查校验和是否等于10的倍数
            check_digit = 10 - (sum_ % 10)
            if check_digit == 10:
                check_digit = 0

            return int(isbn[12]) == check_digit

        # 输入校验
        def validate_input(isbn):
            # ISBN必须是字符串
            if not (entryName.get()):
                tkinter.messagebox.showerror('错误','未获取到ISBN编码')
            # ISBN必须是13位数字，可以包含减号和空格
            if len(isbn) != 13 or not isbn.replace("-", "").replace(" ", "").isdigit():
                tkinter.messagebox.showerror('错误', 'ISBN必须是 13 位数字。')
    # 测试
    def show():
        isbn = entryName.get()
        check.validate_input(isbn)
        if check.validate_isbn13(isbn):
            tkinter.messagebox.showinfo('结果', 'ISBN有效。')
        else:
            tkinter.messagebox.showinfo('结果', 'ISBN无效。')

    CheckButton = tkinter.Button(ISBN_Root,
                                 text='校验',
                                 width=40,
                                 command=show)
    CheckButton.place(x=270, y=30, width=70, height=20)

    ISBN_Root.mainloop()

#