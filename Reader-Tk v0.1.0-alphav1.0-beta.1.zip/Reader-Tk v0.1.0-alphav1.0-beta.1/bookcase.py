import tkinter as tk
import tkinter.ttk as ttk
from tkinter.ttk import Treeview
import csv
import note_list

def bookcase_win():
    bookcase = tk.Tk()
    bookcase.title('书架')
    bookcase.resizable(False, False) # 使窗口无法缩放。
    menu = tk.Menu(bookcase)

    app_width = 980
    app_height = 690
    display_width = bookcase.winfo_screenwidth()
    display_height = bookcase.winfo_screenheight()
    x = int((display_width - app_width) / 2)
    y = int((display_height - app_height) / 2)
    bookcase.geometry(f'{app_width}x{app_height}+{x}+{y}')

    name = tk.StringVar(bookcase, value='')
    nationality = tk.StringVar(bookcase, value='')
    author = tk.StringVar(bookcase, value='')
    publishing_house = tk.StringVar(bookcase, value='')
    ISBN = tk.StringVar(bookcase, value='')
    year = tk.StringVar(bookcase, value='')
    month = tk.StringVar(bookcase, value='')
    day = tk.StringVar(bookcase, value='')
    price = tk.StringVar(bookcase, value='')

    ttk.Label(bookcase, text='名称').place(x=24, y=0, width=50, height=25)
    ttk.Entry(bookcase, textvariable=name).place(x=77, y=0, width=300, height=25)
    ttk.Label(bookcase, text='作者').place(x=377, y=0, width=50, height=25)
    ttk.Label(bookcase, text='[').place(x=427, y=0, width=20, height=25)
    ttk.Entry(bookcase, textvariable=nationality).place(x=447, y=0, width=25, height=25)
    ttk.Label(bookcase, text=']').place(x=472, y=0, width=20, height=25)
    ttk.Entry(bookcase, textvariable=author).place(x=492, y=0, width=350, height=25)

    ttk.Label(bookcase, text='出版社').place(x=12, y=25, width=75, height=25)
    ttk.Entry(bookcase, textvariable=publishing_house).place(x=75, y=25, width=400, height=25)
    ttk.Label(bookcase, text='ISBN').place(x=500, y=25, width=80, height=25)
    ttk.Entry(bookcase, textvariable=ISBN).place(x=580, y=25, width=258, height=25)

    ttk.Label(bookcase, text='购买时间').place(x=0, y=50, width=100, height=25)
    ttk.Entry(bookcase, textvariable=year).place(x=75, y=50, width=100, height=25)
    ttk.Label(bookcase, text='-').place(x=175, y=50, width=20, height=25)
    ttk.Entry(bookcase, textvariable=month).place(x=195, y=50, width=50, height=25)
    ttk.Label(bookcase, text='-').place(x=245, y=50, width=20, height=25)
    ttk.Entry(bookcase, textvariable=day).place(x=265, y=50, width=50, height=25)

    ttk.Label(bookcase, text='定价').place(x=25, y=75, width=50, height=25)
    ttk.Entry(bookcase, textvariable=price).place(x=75, y=75, width=100, height=25)
    ttk.Label(bookcase, text='¥').place(x=175, y=75, width=20, height=25)

    ttk.Label(bookcase, text='状态').place(x=200, y=75, width=50, height=25)
    book_state = tk.IntVar(bookcase, value=1)
    ttk.Radiobutton(bookcase, value=1, text='未读完', variable=book_state).place(x=250, y=75, width=200, height=25)
    ttk.Radiobutton(bookcase, value=0, text='已读完', variable=book_state).place(x=450, y=75, width=200, height=25)


    #使用Treeview组件实现表格功能
    frame = ttk.Frame(bookcase)
    frame.place(x=0, y=100, width=980, height=500)
    #滚动条
    scrollBar = tk.Scrollbar(frame)
    scrollBar.pack(side=tk.RIGHT, fill=tk.Y)
    #Treeview组件，6列，显示表头，带垂直滚动条
    columns = ['书名', '作者', '出版社', 'ISBN', '购买时间', '定价', '状态']
    tree = Treeview(frame, columns=columns, show="headings", yscrollcommand=scrollBar.set)
    #设置每列宽度和对齐方式
    tree.column('书名', width=100, anchor='center')
    tree.column('作者', width=100, anchor='center')
    tree.column('出版社', width=185, anchor='center')
    tree.column('ISBN', width=245, anchor='center')
    tree.column('购买时间', width=170, anchor='center')
    tree.column('定价', width=80, anchor='center')
    tree.column('状态', width=80, anchor='center')
    #设置每列表头标题文本
    tree.heading('书名', text='书籍')
    tree.heading('作者', text='作者')
    tree.heading('出版社', text='出版社')
    tree.heading('ISBN', text='ISBN')
    tree.heading('购买时间', text='购买时间')
    tree.heading('定价', text='定价')
    tree.heading('状态', text='状态')
    tree.pack(side=tk.LEFT, fill=tk.Y)
    #Treeview组件与垂直滚动条结合
    scrollBar.config(command=tree.yview)

    def insert():
        # 添加数据
        author_name = '[' + nationality.get() + ']' + author.get()
        time = year.get() + '-' + month.get() + '-' + day.get()
        book_state_ = {0: '已读完', 1: '未读完'}
        book_info = [[name.get(), author_name, publishing_house.get(), ISBN.get(),time , price.get()+'¥', book_state_[book_state.get()]]]
        for index, data in enumerate(book_info):
            tree.insert('', tk.END, values=data)
        name.set(value='')# 添加后清空内容。
        nationality.set(value='')
        author.set(value='')
        publishing_house.set(value='')
        year.set(value='')
        month.set(value='')
        day.set(value='')
        ISBN.set(value='')
        price.set(value='')

    ttk.Button(bookcase, text='添加', command=insert).place(x=525, y=600, width=75, height=25)

    def delete():
        selected_item = tree.selection()
        tree.delete(selected_item)

    ttk.Button(bookcase, text='删除', command=delete).place(x=600, y=600, width=75, height=25)

    def load_file():
        with open('bookfile.csv', 'r', encoding='utf-8', errors='ignore') as bookfile:
            csvread = csv.reader(bookfile, delimiter=',')

            for row in csvread:
                tree.insert('', tk.END, values=row)

        load_button = ttk.Button(bookcase, text='加载', command=load_file, state=tk.DISABLED).place(x=675, y=600, width=75,height=25)
        # state=tk.DISABLED 加载后立即替换可按按钮为禁用的不可按按钮，放置用户调皮重复加载。

    def save_file():
        with open('bookfile.csv', 'w', encoding='utf-8', newline='', errors='ignore') as bookfile:
            csvsave = csv.writer(bookfile, delimiter=',')

            for row_id in tree.get_children():
                row = tree.item(row_id)['values']
                csvsave.writerow(row)
    ttk.Button(bookcase, text='保存', command=save_file).place(x=750, y=600, width=75, height=25)
    load_button = ttk.Button(bookcase, text='加载', command=load_file).place(x=675, y=600, width=75,height=25)
    #定义并绑定Treeview组件的鼠标单击事件

    def open_note_list():
        bookcase.withdraw()
        note_list.list()

    ttk.Button(bookcase, text='笔记列表', command=open_note_list).place(x=800, y=665, width=125, height=25)

    def finish_state():
        iid = tree.selection()
        text = tree.item(iid)['values']

        book_info = [[text[0], text[1], text[2], text[3], text[4], text[5], '已读完']]
        for index, data in enumerate(book_info):
            tree.insert('', tk.END, values=data)
        tree.delete(iid)

    ttk.Button(bookcase, text='已完成', command=finish_state).place(x=525, y=625, width=75, height=25)

    def go_home():
        bookcase.destroy()

    ttk.Button(bookcase, text='返回', command=go_home).place(x=850, y=600, width=75, height=25)

    def treeviewClick(event):
        pass
    tree.bind('<Button-1>', treeviewClick)

    #运行程序，启动事件循环

    bookcase.mainloop()
