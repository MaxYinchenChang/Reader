import tkinter
import tkinter.messagebox

def info_window(title, message, yes_button_command):
    info_window = tkinter.Tk()
    info_window.title(title)
    info_window['width'] = 275
    info_window['height'] = 125
    # 设置文字显示位置
    text = tkinter.Label(info_window,
                              text=message,
                              justify=tkinter.RIGHT,
                              width=80)
    text.place(x=10, y=5, width=80, height=20)
    def no_button_command():
        info_window.destroy()
        # 当用户点击 否，关闭窗口。

    def yes():
        yes_button_command
        info_window.destroy()

    yes_button = tkinter.Button(info_window, text='是', command=yes)
    no_button = tkinter.Button(info_window, text='否', command=no_button_command)
    yes_button.place(x=210, y=75)
    no_button.place(x=240, y=75)



    info_window.mainloop()

